#!/bin/bash

python3 perceptron.py
